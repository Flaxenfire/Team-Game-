using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerMovement : MonoBehaviour
{
    public CharacterController2D controller;
    public gameStart turnManager;
    float horizontalMove = 0f;
    public float runSpeed = 35f;
    bool jump = false;
    public Rigidbody2D rb;
    public float player1Stamina = 100;
    public float player2Stamina = 100;
    public int health = 100;
    public Text HealthText;
    public Text StaminaText;
    public Animator animator;
    public bool shocked;
    public bool wounded;
    public int powerUp;


    // Update is called once per frame
    void Update()
    {
        if (turnManager.warrior3 == true)
        {
            health += 5;
            turnManager.warrior3 = false;
        }
        
        HealthText.text = health.ToString();
        StaminaText.text = player1Stamina.ToString();

        if (wounded == true)
        {
            if (player1Stamina <= 50)
            {
                health -= 20;
                wounded = false;    
            }
        }
        if (turnManager.player1turn)
        {
            horizontalMove = Input.GetAxisRaw("Horizontal") * runSpeed;

            animator.SetFloat("Speed", Mathf.Abs(horizontalMove));

            if (shocked == false)
            {
                if (Input.GetButtonDown("Jump"))
                {
                    jump = true;
                    animator.SetBool("IsJumping", true);
                }
            }
            if (Input.GetButtonDown("Fire3"))
            {
                animator.SetFloat("Speed", 0);
                turnManager.player1turn = false;
                turnManager.player1attack = true;
                rb.drag = 20;
                player1Stamina = 100;
                shocked = false;
                runSpeed = 35f;
                wounded = false;
            }
            if (player1Stamina == 0)
            {
                animator.SetFloat("Speed", 0);
                turnManager.player1turn = false;
                turnManager.player1attack = true;
                rb.drag = 20;
                player1Stamina = 100;
                shocked = false;
                runSpeed = 35f;
                wounded = false;
            }

        }
        else if (turnManager.player2attack)
        {
            if (Input.GetButtonDown("Fire1") || Input.GetButtonDown("Fire2") || Input.GetButtonDown("Fire4"))
            {
                turnManager.player1turn = true;
                turnManager.player2attack = false;
                rb.drag = 0;
                player2Stamina = 100;
            }
        }
        else if (turnManager.player2turn)
        {
            if (Input.GetButtonDown("Fire3"))
            {
                turnManager.player2attack = true;
                turnManager.player2turn = false;
                player2Stamina = 100;
            }
            if (player2Stamina == 0)
            {
                turnManager.player2attack = true;
                turnManager.player2turn = false;
                player2Stamina = 100;
            }
        }
    }

    public void TakeDamage (int damage)
    {
        health -= damage;
        if (health <= 0)
        {
            Die();
        }
    }

    public void Shocked()
    {
        shocked = true;
    }

    public void Frozen()
    {
        runSpeed = 17f;
    }

    public void Wounded()
    {
        wounded = true;
    }

    public void PowerUp()
    {
        powerUp = Random.Range(1, 4);
        if (powerUp == 1)
        {
            health += 10;
        }
        if (powerUp == 2)
        {
            health += 25;
        }
        if (powerUp == 3)
        {
            health += 50;
        }
    }

    void Die ()
    {
        Destroy(gameObject);
    }

    public void OnLanding()
    {
        animator.SetBool("IsJumping", false);
    }

    void FixedUpdate () {

        if (turnManager.player1turn)
        {
            controller.Move(horizontalMove * Time.fixedDeltaTime, false, jump);
            jump = false;
            if (player1Stamina != 0)
            {
                if (Input.GetButton("Horizontal"))
                    player1Stamina -= 1;
            }
        }
        if (turnManager.player2turn)
        {
            if (player2Stamina != 0)
            {
                if (Input.GetButton("Horizontal"))
                    player2Stamina -= 1;
            }
        }
    }
}