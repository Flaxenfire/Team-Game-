using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUp : MonoBehaviour
{
	void OnTriggerEnter2D(Collider2D hitInfo)
	{
		PlayerMovement player = hitInfo.GetComponent<PlayerMovement>();
		if (player != null)
		{
			player.PowerUp();
			Destroy(gameObject);
		}

		Player_2_Moverment player2 = hitInfo.GetComponent<Player_2_Moverment>();
		if (player2 != null)
		{
			player2.PowerUp();
			Destroy(gameObject);
		}
	}
}
