using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ice : MonoBehaviour
{
	public float spd = 20f;
	public int damage = 25;
	public Rigidbody2D rb;

	// Update is called once per frame

	void Update()
	{
		rb.velocity = transform.right * spd;
	}

	void OnTriggerEnter2D(Collider2D hitInfo)
	{
		PlayerMovement enemy = hitInfo.GetComponent<PlayerMovement>();
		if (enemy != null)
		{
			enemy.TakeDamage(damage);
			enemy.Frozen();
		}

		Player_2_Moverment enemy2 = hitInfo.GetComponent<Player_2_Moverment>();
		if (enemy2 != null)
		{
			enemy2.TakeDamage(damage);
			enemy2.Frozen();
		}

		Destroy(gameObject);
	}
}
