using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gameStart : MonoBehaviour
{ 
public bool player1turn;
public bool player1attack;
public bool player2turn;
public bool player2attack;
public bool warrior3;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
