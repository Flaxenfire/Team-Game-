using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon2 : MonoBehaviour
{
	public Transform firePoint;
	public GameObject bulletPrefab;
	public gameStart turnManager;
	public GameObject bombPrefab;
	public GameObject meleePrefab;

	// Update is called once per frame
	void Update()
	{
		if (turnManager.player2attack)
		{
			if (Input.GetButtonDown("Fire1"))
			{
				Shoot();
				turnManager.player2attack = false;
				turnManager.player1turn = true;
			}
			else if (Input.GetButtonDown("Fire2"))
			{
				Shoot1();
				turnManager.player2attack = false;
				turnManager.player1turn = true;
			}
			else if (Input.GetButtonDown("Fire4"))
			{
				Shoot2();
				turnManager.player2attack = false;
				turnManager.player1turn = true;
			}
		}
	}
	void Shoot()
	{
		Instantiate(bulletPrefab, firePoint.position, firePoint.rotation);
	}
	void Shoot1()
	{
		Instantiate(bombPrefab, firePoint.position, firePoint.rotation);
	}
	void Shoot2()
	{
		Instantiate(meleePrefab, firePoint.position, firePoint.rotation);
	}
}
