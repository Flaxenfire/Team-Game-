
				Pixel Art created by Vicente Nitti (@vnitti)

			Thank you for using: "GRASSY MOUNTAINS: PARALLAX BACKGROUND"

=== CONTENT ===
far_mountains.png
grassy_mountains.png
hill.png
clouds_front.png
clouds_mid.png
clouds_front_t.png
clouds_mid_t.png
sky.png
far_mountains_fc.png
grassy_mountains_fc.png
hill_fc.png
clouds_front_fc.png
clouds_mid_fc.png
clouds_front_t_fc.png
clouds_mid_t_fc.png
sky_fc.png
Grassy_Mountains_preview.png
Grassy_Mountains_preview_fullcolor.png
Grassy_Mountains.psd
Readme.txt



=== LICENSE ===
This pixel art piece is licensed under a Creative Commons Atribution 4.0 International license CC BY 4.0,
which reads the following:

You are free to:
	+ Share � copy and redistribute the material in any medium or format
	+ Adapt � remix, transform, and build upon the material for any purpose, even commercially.

Under the following terms:
	+ Attribution � You must give appropriate credit, provide a link to the license, and indicate if
	  changes were made. You may do so in any reasonable manner, but not in any way that suggests the
	  licensor endorses you or your use.

	+ No additional restrictions � You may not apply legal terms or technological measures that legally
	  restrict others from doing anything the license permits.

License - http://creativecommons.org/licenses/by/4.0/

You are not required to credit this asset if you paid for it. However it will be greatly appreciated.

Please, do not redistribute this material or claim as if it were of your authorship.



=== FIND ME ON ===
Twitter:   https://twitter.com/vnitti_art
Itch.io:   https://vnitti.itch.io/
Patreon:   https://patreon.com/vnitti
Portfolio: https://deviantart.com/vnitti


				Have a good developing! - Vicente Nitti