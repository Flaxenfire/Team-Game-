using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BombScript : MonoBehaviour
{

	public float sped = 4f;
	public Vector3 LaunchOffset;
	public bool Thrown;
	public int damage = 25;

	void Start()
	{
		if (Thrown)
		{
			var direction = transform.right + Vector3.up;
			GetComponent<Rigidbody2D>().AddForce(direction * sped, ForceMode2D.Impulse);
		}
		transform.Translate(LaunchOffset);
	}

	void Update()
	{
		if (!Thrown)
		{
			transform.position += transform.right * sped * Time.deltaTime;
		}
	}



	void OnTriggerEnter2D(Collider2D hitInfo)
	{
		PlayerMovement enemy = hitInfo.GetComponent<PlayerMovement>();
		if (enemy != null)
		{
			enemy.TakeDamage(damage);
		}

		Player_2_Moverment enemy2 = hitInfo.GetComponent<Player_2_Moverment>();
		if (enemy2 != null)
		{
			enemy2.TakeDamage(damage);
		}

		Destroy(gameObject);
	}


}