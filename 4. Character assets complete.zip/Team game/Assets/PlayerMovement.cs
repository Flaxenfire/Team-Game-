using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerMovement : MonoBehaviour
{
    public CharacterController2D controller;

    public gameStart turnManager;

    float horizontalMove = 0f;

    public float runSpeed = 40f;

    bool jump = false;

    public Rigidbody2D rb;

    public float player1Stamina = 100;

    public float player2Stamina = 100;

    public int health = 100;

    public Text HealthText;

    public Text StaminaText;

    public Animator animator;


    // Update is called once per frame
    void Update()
    {
        if (turnManager.warrior3 == true)
        {
            health += 5;
            turnManager.warrior3 = false;
        }
        HealthText.text = health.ToString();
        StaminaText.text = player1Stamina.ToString();
        if (turnManager.player1turn)
        {
            horizontalMove = Input.GetAxisRaw("Horizontal") * runSpeed;

            animator.SetFloat("Speed", Mathf.Abs(horizontalMove));

            if (Input.GetButtonDown("Jump"))
            {
                jump = true;
                animator.SetBool("IsJumping", true);
            }
            if (Input.GetButtonDown("Fire3"))
            {
                animator.SetFloat("Speed", 0);
                turnManager.player1turn = false;
                turnManager.player1attack = true;
                rb.drag = 20;
                player1Stamina = 100;
            }
            if (player1Stamina == 0)
            {
                animator.SetFloat("Speed", 0);
                turnManager.player1turn = false;
                turnManager.player1attack = true;
                rb.drag = 20;
                player1Stamina = 100;
            }

        }
        else if (turnManager.player2attack)
        {
            if (Input.GetButtonDown("Fire1") || Input.GetButtonDown("Fire2") || Input.GetButtonDown("Fire4"))
            {
                turnManager.player1turn = true;
                turnManager.player2attack = false;
                rb.drag = 0;
                player2Stamina = 100;
            }
        }
        else if (turnManager.player2turn)
        {
            if (Input.GetButtonDown("Fire3"))
            {
                turnManager.player2attack = true;
                turnManager.player2turn = false;
                player2Stamina = 100;
            }
            if (player2Stamina == 0)
            {
                turnManager.player2attack = true;
                turnManager.player2turn = false;
                player2Stamina = 100;
            }
        }
    }

    public void TakeDamage (int damage)
    {
        health -= damage;
        if (health <= 0)
        {
            Die();
        }
    }

    void Die ()
    {
        Destroy(gameObject);
    }

    public void OnLanding()
    {
        animator.SetBool("IsJumping", false);
    }

    void FixedUpdate () {

        if (turnManager.player1turn)
        {
            controller.Move(horizontalMove * Time.fixedDeltaTime, false, jump);
            jump = false;
            if (player1Stamina != 0)
            {
                if (Input.GetButton("Horizontal"))
                    player1Stamina -= 1;
            }
        }
        if (turnManager.player2turn)
        {
            if (player2Stamina != 0)
            {
                if (Input.GetButton("Horizontal"))
                    player2Stamina -= 1;
            }
        }
    }
}