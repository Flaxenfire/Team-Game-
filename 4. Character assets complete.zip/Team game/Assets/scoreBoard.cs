using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*To let the round variable become the global variable */
public static class scoreBoard
{
    public static int round = 1;
}
