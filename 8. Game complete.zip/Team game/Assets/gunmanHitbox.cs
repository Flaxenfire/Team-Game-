using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class gunmanHitbox : MonoBehaviour
{

    public int damage = 35;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(Wait1Second());

    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private IEnumerator Wait1Second()
    {
        yield return new WaitForSeconds(1f);
        Destroy(gameObject);
    }
    void OnTriggerEnter2D(Collider2D hitInfo)
    {
        PlayerMovement enemy = hitInfo.GetComponent<PlayerMovement>();
        if (enemy != null)
        {
            enemy.TakeDamage(damage);
            Destroy(gameObject);
        }

        Player_2_Moverment enemy2 = hitInfo.GetComponent<Player_2_Moverment>();
        if (enemy2 != null)
        {
            enemy2.TakeDamage(damage);
            Destroy(gameObject);
        }
    }
}