using System.Collections;  
using System.Collections.Generic;  
using UnityEngine;  
using UnityEngine.SceneManagement;  
public class MainMenu: MonoBehaviour {

	public static bool p1_gun = true;
	public static bool p2_gun = true;
	public static bool p1_mage = true;
	public static bool p2_mage = true;
	public static bool p1_war = true;
	public static bool p2_war = true;

	public void PlayGame() {  
		SceneManager.LoadScene("Player1");  
	} 
	public void doExitGame() {
		Application.Quit();
	}
	
	public void character1Mage() {
		p1_gun = false;
		p1_war = false;
		SceneManager.LoadScene("Player2"); 
	}
	
	public void character2Mage()
	{
		p2_gun = false;
		p2_war = false;
		SceneManager.LoadScene("SampleScene");
	}
	
	public void character1Gun()
	{
		p1_mage = false;
		p1_war = false;
		SceneManager.LoadScene("Player2");
	}
	
	public void character2Gun()
	{
		p2_mage = false;
		p2_war = false;
		SceneManager.LoadScene("SampleScene");
	}
	
	public void character1War()
	{
		p1_gun = false;
		p1_mage = false;
		SceneManager.LoadScene("Player2");
	}
	
	public void character2War()
	{
		p2_gun = false;
		p2_mage = false;
		SceneManager.LoadScene("SampleScene");
	}

	public void controls()
    {
		SceneManager.LoadScene("Controls");
	}

	public void credits()
    {
		SceneManager.LoadScene("Credits");
    }

	public void menu()
    {
		SceneManager.LoadScene("MainMenu");
    }
}  