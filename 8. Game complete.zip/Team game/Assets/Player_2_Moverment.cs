using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Player_2_Moverment : MonoBehaviour
{
    public CharacterController2D controller;
    public gameStart turnManager;
    float horizontalMove = 0f;
    public float runSpeed = 35f;
    bool jump = false;
    public Rigidbody2D rb;
    public float player1Stamina = 125;
    public float player2Stamina = 125;
    public int health = 100;
    public Text HealthText;
    public Text StaminaText;
    public Animator animator;
    public bool shocked;
    public bool wounded;
    public int powerUp;
    public Text Status;
    public Text Phase;


    // Update is called once per frame
    void Update()
    {
        if (turnManager.warrior3 == true)
        {
            health += 5;
            turnManager.warrior3 = false;
        }

        HealthText.text = health.ToString();
        StaminaText.text = player2Stamina.ToString();

        if (wounded == true)
        {
            if (player2Stamina <= 50)
            {
                health -= 20;
                animator.SetTrigger("Damage");
                if (health <= 0)
                {
                    Die();
                    scoreBoard.round = 1;
                    MainMenu.p1_gun = true;
                    MainMenu.p2_gun = true;
                    MainMenu.p1_mage = true;
                    MainMenu.p2_mage = true;
                    MainMenu.p1_war = true;
                    MainMenu.p2_war = true;
                    SceneManager.LoadScene("P1Win");
                }
                wounded = false;
            }
        }
        if (turnManager.player2turn)
        {
            horizontalMove = Input.GetAxisRaw("Horizontal") * runSpeed;

            animator.SetFloat("Speed", Mathf.Abs(horizontalMove));

            if (shocked == false)
            {
                if (Input.GetButtonDown("Jump"))
                {
                    jump = true;
                    animator.SetBool("IsJumping", true);
                }
            }
            if (Input.GetButtonDown("Fire3"))
            {
                animator.SetFloat("Speed", 0);
                turnManager.player2attack = true;
                turnManager.player2turn = false;
                rb.drag = 20;
                player2Stamina = 125;
                shocked = false;
                runSpeed = 35f;
                wounded = false;
                Status.text = "[NO STATUS]";
                Status.color = Color.white;
                Phase.text = "Player 2 Attack";
            }
            if (player2Stamina == 0)
            {
                animator.SetFloat("Speed", 0);
                turnManager.player2attack = true;
                turnManager.player2turn = false;
                rb.drag = 20;
                player2Stamina = 125;
                shocked = false;
                runSpeed = 35f;
                wounded = false;
                Status.text = "[NO STATUS]";
                Status.color = Color.white;
                Phase.text = "Player 2 Attack";
            }

        }
        else if (turnManager.player1attack)
        {
            if (Input.GetButtonDown("Fire1") || Input.GetButtonDown("Fire2") || Input.GetButtonDown("Fire4"))
            {
                turnManager.player1attack = false;
                turnManager.player2turn = true;
                rb.drag = 0;
                player1Stamina = 125;
                Phase.text = "Player 2 Move";
            }
        }
        else if (turnManager.player1turn)
        {
            if (Input.GetButtonDown("Fire3"))
            {
                turnManager.player1turn = false;
                turnManager.player1attack = true;
                player1Stamina = 125;
                Phase.text = "Player 1 Attack";
            }
            if (player1Stamina == 0)
            {
                turnManager.player1turn = false;
                turnManager.player1attack = true;
                player1Stamina = 125;
                Phase.text = "Player 1 Attack";
            }
        }  
    }

    public void TakeDamage (int damage)
    {
        health -= damage;
        animator.SetTrigger("Damage");
        if (health <= 0)
        {
            Die();
            scoreBoard.round = 1;
            MainMenu.p1_gun = true;
            MainMenu.p2_gun = true;
            MainMenu.p1_mage = true;
            MainMenu.p2_mage = true;
            MainMenu.p1_war = true;
            MainMenu.p2_war = true;
            SceneManager.LoadScene("P1Win");
        }
    }

    public void Shocked()
    {
        shocked = true;
        Status.text = "[SHOCKED]";
        Status.color = Color.yellow;
    }

    public void Frozen()
    {
        runSpeed = 17f;
        Status.text = "[FROZEN]";
        Status.color = Color.cyan;
    }

    public void Wounded()
    {
        wounded = true;
        Status.text = "[WOUNDED]";
        Status.color = Color.red;
    }

    public void PowerUp()
    {
        powerUp = Random.Range(1, 4);
        if (powerUp == 1)
        {
            health += 10;
        }
        if (powerUp == 2)
        {
            health += 25;
        }
        if (powerUp == 3)
        {
            health += 50;
        }
    }

    void Die ()
    {
        Destroy(gameObject);
    }

    public void OnLanding ()
    {
        animator.SetBool("IsJumping", false);
    }

    void FixedUpdate()
    {
        if (turnManager.player2turn)
        {
            controller.Move(horizontalMove * Time.fixedDeltaTime, false, jump);
            jump = false;
            if (player2Stamina != 0)
            {
                if (Input.GetButton("Horizontal"))
                    player2Stamina -= 1;
            }
        }
        if (turnManager.player1turn)
        {
            if (player1Stamina != 0)
            {
                if (Input.GetButton("Horizontal"))
                    player1Stamina -= 1;
            }
        }
    }
}